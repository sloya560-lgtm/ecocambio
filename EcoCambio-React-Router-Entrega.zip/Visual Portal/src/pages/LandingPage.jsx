import { useEffect, useRef, useState } from 'react'
import {
  ArrowLeft, ArrowRight, BadgeCheck, BookOpen, Check, ChevronDown,
  ChevronLeft, ChevronRight, CircleHelp, Heart, Leaf, LockKeyhole, LogIn,
  Menu, MessageCircle, Minus, Plus, Search, ShieldCheck, ShoppingBag, Trash2,
  UserRound, X,
} from 'lucide-react'
import { Link } from 'react-router'
import '../App.css'

const notebookDesigns = [
  { id: 'zorro', name: 'El zorro curioso', image: 'photo-1531346878377-a5be20888e57', note: 'Una portada para las ideas inquietas.' },
  { id: 'jardin', name: 'Mi jardín', image: 'photo-1517842645767-c639042777db', note: 'Hojas nuevas para todo lo que quieres aprender.' },
  { id: 'mar', name: 'Mar de colores', image: 'photo-1455390582262-044cdead277a', note: 'Una libreta hecha para llenar de historias.' },
  { id: 'papalote', name: 'Cielo de papalotes', image: 'photo-1519682337058-a94d519337bc', note: 'Papel recuperado, listo para tomar vuelo.' },
]

const products = notebookDesigns.flatMap((design) => [
  { id: `${design.id}-ch`, name: `${design.name} · Chica`, price: 150, stock: 5, design: design.id, image: design.image, detail: 'Libreta artesanal con papel recuperado y portada ilustrada.' },
  { id: `${design.id}-gr`, name: `${design.name} · Grande`, price: 250, stock: 5, design: design.id, image: design.image, detail: 'Cuaderno artesanal de mayor formato, hecho con papel recuperado.' },
])

const categories = ['Todo', 'Mochilas', 'Ropa', 'Uniformes', 'Libros', 'Cuadernos', 'Útiles', 'Tecnología', 'Otros']
const suggestedAmounts = [50, 100, 200, 500]
const adminEmails = ['admin@cbtis122.edu.mx']
const schoolDomain = 'cbtis122.edu.mx'
const day = 24 * 60 * 60 * 1000

const policies = {
  terms: {
    title: 'Términos y condiciones',
    sections: [
      ['Uso de EcoCambio', 'EcoCambio es un proyecto escolar del CBTis 122 para facilitar el intercambio y la donación de artículos útiles, y dar visibilidad a las libretas elaboradas con cuadernos recuperados. La participación y la entrega se coordinan entre integrantes de la comunidad.'],
      ['Datos pendientes', 'Antes de publicar una versión definitiva, completar el nombre de la persona responsable, el domicilio de contacto, correo oficial, horarios, jurisdicción aplicable y proceso para atender aclaraciones.'],
    ],
  },
  privacy: {
    title: 'Privacidad y datos personales',
    sections: [
      ['Datos solicitados', 'La cuenta puede solicitar nombre, correo institucional y número de control. Una donación física pide nombre completo, dirección, teléfono y cantidad de cuadernos. Las solicitudes privadas y los pedidos recaban únicamente los datos necesarios para darles seguimiento.'],
      ['Uso en esta versión', 'Los datos se guardan en el almacenamiento local de este navegador y no se envían a un servidor. No ingreses información sensible en esta demostración. Antes de operar públicamente, la escuela debe definir responsable, plazo de conservación, seguridad y canal para atender solicitudes sobre los datos.'],
      ['Pendiente institucional', 'Completar quién es responsable del tratamiento, domicilio y correo de privacidad, así como el mecanismo para actualizar o eliminar información.'],
    ],
  },
  platform: {
    title: 'Política de uso de la plataforma',
    sections: [
      ['Publicaciones', 'Las publicaciones del catálogo escolar pueden ofrecerse como donación o intercambio. Deben corresponder a artículos escolares o de uso personal y respetar las reglas de convivencia del plantel.'],
      ['Entregas', 'El proyecto propone la biblioteca del CBTis 122 como punto de encuentro para coordinar entregas. Los horarios y el procedimiento final deben confirmarse con el plantel.'],
      ['Alcance', 'La información de perfiles y publicaciones se almacena localmente en esta versión. Para operar entre diferentes dispositivos se requiere un servicio de servidor y controles de acceso.'],
    ],
  },
  purchases: {
    title: 'Compras y pagos',
    sections: [
      ['Pedidos de libretas', 'El carrito conserva productos en el navegador. Confirmar un pedido lo registra como pendiente para revisión; no confirma existencias ni genera un cobro.'],
      ['Pasarelas', 'Mercado Pago, PayPal y tarjeta son métodos previstos, pero todavía no están conectados. Se requiere una cuenta comercial, un backend que cree las órdenes y gestione webhooks, credenciales privadas en servidor y URLs de retorno. Esta página nunca solicita ni almacena datos de tarjeta.'],
      ['Condiciones por completar', 'Definir precios finales, entrega, cancelaciones, devoluciones, comprobantes y contacto de atención antes de recibir pagos reales.'],
    ],
  },
  donations: {
    title: 'Política de donaciones',
    sections: [
      ['Cuadernos físicos', 'Las donaciones físicas se registran por separado del catálogo. No son artículos a la venta y no aparecen en publicaciones. El equipo debe coordinar su recepción con la persona donante.'],
      ['Aportaciones económicas', 'Una aportación monetaria es distinta de comprar una libreta. En esta versión solo se registra una intención de donar; no se procesa ningún pago.'],
      ['Pendiente de definir', 'Completar responsable de recepción, destino de las aportaciones, comprobantes y canal para resolver dudas.'],
    ],
  },
}

function readStorage(key, fallback) {
  try {
    const stored = localStorage.getItem(key)
    return stored ? JSON.parse(stored) : fallback
  } catch {
    return fallback
  }
}

function writeStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch {
    return false
  }
  return true
}

function migrateUsers(accounts) {
  return accounts.map((account) => ({
    ...account,
    name: account.name || account.nom || '',
    password: account.password || account.pw || '',
    studentNumber: account.studentNumber || account.ctl || '',
  }))
}

function migratePosts(items) {
  return items.map((post) => ({
    ...post,
    email: post.email || post.em || '',
    status: post.status || ({ ok: 'ok', rev: 'review', rech: 'rejected', exp: 'expired' }[post.st] || 'ok'),
  }))
}

function migrateNotices(items) {
  return items.map((notice) => ({
    ...notice,
    message: notice.message || notice.t || '',
    read: notice.read ?? Boolean(notice.l),
  }))
}

const formatMoney = (value) => new Intl.NumberFormat('es-MX', {
  style: 'currency', currency: 'MXN', maximumFractionDigits: 0,
}).format(value || 0)
const formatDate = (value) => new Date(value).toLocaleDateString('es-MX', { day: 'numeric', month: 'short' })
const initials = (name = '') => name.split(/[ .]/).filter(Boolean).slice(0, 2).map((part) => part[0].toUpperCase()).join('')
const normalize = (value = '') => String(value).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
const filteredWords = /\b(puto|puta|pendej\w*|verga|chinga\w*|mierda|cabr[oó]n\w*|drogas?|marihuana|pistola|vape|alcohol)\b/i
const makeRecordId = (prefix) => `${prefix}${Date.now()}`

function useLocalState(key, fallback, migrate = (value) => value) {
  const [value, setValue] = useState(() => migrate(readStorage(key, fallback)))
  useEffect(() => { writeStorage(key, value) }, [key, value])
  return [value, setValue]
}
function Picture({ image, alt, className = '' }) {
  return <img className={className} src={`https://images.unsplash.com/${image}?auto=format&fit=crop&w=950&q=82`} alt={alt} loading="lazy" />
}

function ProgressMeter({ raised, target }) {
  const amount = Math.max(0, Number(raised) || 0)
  const goal = Math.max(1, Number(target) || 10000)
  const percent = Math.min(100, Math.round(amount / goal * 100))
  return <aside className="campaign-meter" aria-label="Avance de la meta para una computadora portátil">
    <div className="meter-illustration" aria-hidden="true"><Leaf className="meter-leaf meter-leaf-one" /><Leaf className="meter-leaf meter-leaf-two" /><BookOpen className="meter-book" /></div>
    <span className="eyebrow">META PARA UNA COMPUTADORA PORTÁTIL</span>
    <strong>{formatMoney(amount)}</strong>
    <div className="meter-track" role="progressbar" aria-label="Aportaciones verificadas" aria-valuemin="0" aria-valuemax={goal} aria-valuenow={Math.min(amount, goal)}><i style={{ width: `${percent}%` }} /></div>
    <p>{formatMoney(amount)} registrados de {formatMoney(goal)} MXN · {percent}%</p>
    <small>El avance solo cambia cuando el equipo registra una cantidad verificada.</small>
  </aside>
}

function PublicSpace({ pageTitle, onDonate, onCause, onMoney, raised, target }) {
  return <section className="content-page public-space-page">
    {pageTitle('ESPACIO PÚBLICO · TODAS LAS PERSONAS', 'Una segunda oportunidad también puede ser tuya.', 'EcoCambio es una iniciativa estudiantil del CBTis 122 para aprovechar materiales, acompañar a estudiantes y convertir la solidaridad en oportunidades para seguir aprendiendo.')}
    <div className="public-cause-banner"><div><span className="eyebrow">ODS 12 · PRODUCCIÓN Y CONSUMO RESPONSABLES</span><h2>Lo que todavía sirve puede cambiarle el día a alguien.</h2><p>Recibimos materiales escolares aprovechables, los acercamos a estudiantes que los necesitan y recuperamos cuadernos para crear libretas artesanales.</p><div className="hero-buttons"><button className="primary-button" onClick={onDonate}>Donar cuadernos usados <Heart size={16} /></button><button className="plain-button" onClick={onCause}>Ver Cuadernos con Causa <ArrowRight size={15} /></button></div></div><div className="cause-doodle" aria-hidden="true"><span className="doodle-sun" /><BookOpen className="doodle-book" /><Leaf className="doodle-leaf" /><Heart className="doodle-heart" /></div></div>
    <div className="public-materials"><div><span className="eyebrow">¿QUÉ RECIBIMOS?</span><h2>Materiales que aún pueden acompañar una clase.</h2><p>No hace falta que sean nuevos. Lo importante es que todavía puedan utilizarse con seguridad y dignidad.</p></div><div className="materials-list"><span><Check size={16} /> Cuadernos con hojas limpias</span><span><Check size={16} /> Hojas y papel aprovechable</span><span><Check size={16} /> Útiles escolares en buen estado</span><span><Check size={16} /> Otros recursos escolares reutilizables</span></div><p className="local-storage-note">El formulario público actual registra donaciones de cuadernos. La recepción de otros materiales se debe coordinar con el equipo del proyecto.</p></div>
    <div className="public-steps"><div className="section-heading-row"><div><span className="eyebrow">ASÍ SE MUEVE LA AYUDA</span><h2>De tus manos a una nueva oportunidad.</h2></div></div><div className="recovery-steps"><article><span>01</span><h3>Nos compartes</h3><p>Indicas qué material puedes donar y cómo contactarte.</p></article><article><span>02</span><h3>Lo revisamos</h3><p>El equipo organiza los materiales para saber cuáles se pueden aprovechar.</p></article><article><span>03</span><h3>Lo hacemos llegar</h3><p>En el CBTis, los recursos se ponen a disposición de estudiantes que los necesitan.</p></article><article><span>04</span><h3>Le damos otra vida</h3><p>Las hojas limpias se convierten en cuadernos artesanales para apoyar la meta solidaria.</p></article></div></div>
    <div className="public-target"><div><span className="eyebrow">UNA META EDUCATIVA</span><h2>Una computadora portátil para continuar estudiando.</h2><p>La meta estimada es de {formatMoney(target)} MXN. El avance se actualiza únicamente con recursos verificados por el equipo.</p><button className="subtle-link" onClick={onMoney}>Conocer cómo aportar dinero <ArrowRight size={14} /></button></div><ProgressMeter raised={raised} target={target} /></div>
    <div className="public-ways"><article><span className="public-way-icon mint"><Heart size={19} /></span><h3>Dona materiales</h3><p>Cuadernos usados con hojas aprovechables, hojas limpias y útiles que todavía sirven.</p><button className="subtle-link" onClick={onDonate}>Registrar una donación <ArrowRight size={14} /></button></article><article><span className="public-way-icon lilac"><BookOpen size={19} /></span><h3>Conoce las libretas</h3><p>Descubre cómo los cuadernos recuperados se transforman en nuevas libretas artesanales.</p><button className="subtle-link" onClick={onCause}>Ver el proyecto <ArrowRight size={14} /></button></article><article><span className="public-way-icon butter"><UserRound size={19} /></span><h3>¿Eres del CBTis?</h3><p>El catálogo de donaciones e intercambios está reservado a la comunidad del plantel.</p><button className="subtle-link" onClick={() => document.querySelector('.signin-button')?.click()}>Entrar al espacio escolar <ArrowRight size={14} /></button></article></div>
    <section className="faq-section"><span className="eyebrow">PREGUNTAS FRECUENTES</span><h2>Lo que conviene saber.</h2><details><summary>¿Solo reciben donaciones de dinero?</summary><p>No. Las donaciones de materiales son fundamentales: aceptamos cuadernos con hojas limpias, hojas sueltas y útiles que todavía puedan aprovecharse.</p></details><details><summary>¿Puedo donar aunque no estudie en el CBTis 122?</summary><p>Sí. El espacio público está abierto a cualquier persona interesada en apoyar. El catálogo de donaciones e intercambios entre estudiantes sí es exclusivo del plantel.</p></details><details><summary>¿Qué pasa con los cuadernos usados?</summary><p>Se revisan, se separan las hojas en buen estado y se preparan para elaborar libretas artesanales con portadas y encuadernación nuevas.</p></details><details><summary>¿Cómo se usa el dinero de las libretas?</summary><p>La meta del proyecto es reunir $10,000 MXN para adquirir una computadora portátil destinada a apoyar la continuidad de estudios. Las cifras de avance solo se mostrarán cuando estén verificadas.</p></details><details><summary>¿Puedo pagar en línea ahora?</summary><p>El sitio todavía no está conectado a una pasarela de pago. Puedes revisar y apartar una libreta de manera provisional, pero no se realizará ningún cobro desde esta página.</p></details></section>
    <aside className="public-school-note"><LockKeyhole size={18} /><div><b>¿Vienes del CBTis 122?</b><p>Inicia sesión con tu correo institucional para ver donaciones, intercambios y solicitudes de la comunidad.</p></div><button className="secondary-button" onClick={() => document.querySelector('.signin-button')?.click()}>Entrar al CBTis</button></aside>
  </section>
}

function App() {
  const [view, setView] = useState(() => {
    const hash = window.location.hash.slice(1)
    return hash.startsWith('post-') ? 'post' : hash || 'inicio'
  })
  const [postId, setPostId] = useState(() => window.location.hash.startsWith('#post-') ? window.location.hash.slice(6) : '')
  const [users, setUsers] = useLocalState('rt_users', [], migrateUsers)
  const [user, setUser] = useState(() => {
    const sessionEmail = readStorage('rt_ses', null)
    return sessionEmail ? migrateUsers(readStorage('rt_users', [])).find((account) => account.email === sessionEmail) || null : null
  })
  const [posts, setPosts] = useLocalState('rt_posts', [], migratePosts)
  const [orders, setOrders] = useLocalState('rt_orders', [])
  const [physicalDonations, setPhysicalDonations] = useLocalState('rt_dons', [])
  const [moneyDonations, setMoneyDonations] = useLocalState('rt_econ_dons', [])
  const [requests, setRequests] = useLocalState('rt_req', [])
  const [comments, setComments] = useLocalState('rt_com', [])
  const [notices, setNotices] = useLocalState('rt_not', [], migrateNotices)
  const [inventory, setInventory] = useLocalState('rt_inv', {})
  const [cart, setCart] = useLocalState('rt_cart', {})
  const [meta, setMeta] = useLocalState('rt_meta', 10000, (value) => Number(value) === 8000 ? 10000 : Number(value) || 10000)
  const [verifiedRaised, setVerifiedRaised] = useLocalState('rt_recaudado_verificado', 0)
  const [modal, setModal] = useState('')
  const [toast, setToast] = useState('')
  const [menuOpen, setMenuOpen] = useState(false)
  const [moreOpen, setMoreOpen] = useState(false)
  const [authMode, setAuthMode] = useState('login')
  const [authError, setAuthError] = useState('')
  const [authNotice, setAuthNotice] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('Todo')
  const [postTypeFilter, setPostTypeFilter] = useState('Todo')
  const [search, setSearch] = useState('')
  const [postError, setPostError] = useState('')
  const [donationAmount, setDonationAmount] = useState('')
  const [selectedPayment, setSelectedPayment] = useState('Efectivo al recoger')
  const [donationComplete, setDonationComplete] = useState(false)
  const [physicalComplete, setPhysicalComplete] = useState(false)
  const [legalPage, setLegalPage] = useState('terms')
  const [uploadPreview, setUploadPreview] = useState('')
  const [registerAsPlantel, setRegisterAsPlantel] = useState(true)
  const [donationAmountError, setDonationAmountError] = useState('')
  const [pendingOrder, setPendingOrder] = useState(null)
  const carouselRef = useRef(null)
  const isAdmin = user?.tipo === 'plantel' && (adminEmails.includes(user.email) || user.email?.includes('admin'))
  const canParticipate = user?.tipo === 'plantel'
  const visiblePosts = posts.filter((post) => post.status === 'ok' || (post.status === 'review' && user && (isAdmin || post.email === user.email)))
  const activePost = posts.find((post) => post.id === postId)
  const productsWithInventory = products.map((product) => ({ ...product, stock: inventory[product.id]?.s ?? product.stock, price: inventory[product.id]?.p ?? product.price }))
  const cartItems = productsWithInventory.filter((product) => cart[product.id] > 0).map((product) => ({ ...product, quantity: Math.min(cart[product.id], product.stock) })).filter((item) => item.quantity > 0)
  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0)
  const cartTotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const receivedAmount = Number(verifiedRaised) || 0
  const unreadNotices = notices.filter((notice) => user && (notice.to === user.email || (isAdmin && notice.to === 'admin')) && !notice.read)
  const schoolOnlyViews = ['catalogo', 'publicar', 'post', 'necesito', 'comentarios', 'pedidos', 'admin']
  const needsSchoolAccess = schoolOnlyViews.includes(view) && !canParticipate

  useEffect(() => {
    const syncRoute = () => {
      const hash = window.location.hash.slice(1)
      if (hash.startsWith('post-')) {
        setView('post')
        setPostId(hash.slice(5))
      } else {
        setView(hash || 'inicio')
        setPostId('')
      }
      setMenuOpen(false)
      setMoreOpen(false)
      window.scrollTo(0, 0)
    }
    window.addEventListener('hashchange', syncRoute)
    return () => window.removeEventListener('hashchange', syncRoute)
  }, [])

  useEffect(() => {
    const titles = { inicio: 'Inicio', publico: 'Espacio público', nosotros: 'Quiénes somos', catalogo: 'Catálogo escolar', publicar: 'Publicar', post: 'Publicación', cuadernos: 'Cuadernos con causa', donar: 'Donación económica', 'dona-cuadernos': 'Dona tus cuadernos', necesito: 'Lo necesito', comentarios: 'Comentarios', pedidos: 'Apartados', pedido: 'Apartar cuaderno', admin: 'Administración', legal: policies[legalPage]?.title }
    document.title = `${titles[view] || 'EcoCambio'} · CBTis 122`
  }, [view, legalPage])

  useEffect(() => {
    if (!toast) return undefined
    const timeout = window.setTimeout(() => setToast(''), 3000)
    return () => window.clearTimeout(timeout)
  }, [toast])

  function navigate(nextView) {
    window.location.hash = nextView
    setMenuOpen(false)
    setMoreOpen(false)
  }

  function addNotice(to, message) {
    setNotices((current) => [{ to, message, ts: Date.now(), read: false }, ...current].slice(0, 60))
  }

  function requireMember() {
    if (!user) {
      setAuthMode('login')
      setAuthError('')
      setAuthNotice('Inicia sesión o crea una cuenta del plantel para participar.')
      setModal('auth')
      return false
    }
    if (!canParticipate) {
      setToast('Solo la comunidad del CBTis 122 puede participar.')
      return false
    }
    return true
  }

  async function hashPassword(password) {
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(password))
    return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('')
  }

  async function submitAuth(event) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const email = String(form.get('email')).trim().toLowerCase()
    const password = String(form.get('password'))
    setAuthError('')
    const existing = users.find((account) => account.email === email)
    if (authMode === 'login') {
      if (!existing || existing.password !== await hashPassword(password)) {
        setAuthError('Correo o contraseña incorrectos.')
        return
      }
      setUser(existing)
      writeStorage('rt_ses', existing.email)
      setModal('')
      setToast(`Hola, ${existing.name.split(' ')[0]}.`)
      return
    }
    const name = String(form.get('name') || '').trim()
    const studentNumber = String(form.get('studentNumber') || '').trim()
    if (name.length < 3) return setAuthError('Escribe tu nombre completo.')
    if (password.length < 6) return setAuthError('La contraseña necesita al menos 6 caracteres.')
    if (existing) return setAuthError('Ese correo ya tiene una cuenta.')
    if (registerAsPlantel) {
      if (!/^\d{8,14}$/.test(studentNumber)) return setAuthError('El número de control debe tener de 8 a 14 dígitos.')
      if (!email.endsWith(schoolDomain)) return setAuthError(`Usa tu correo institucional terminado en ${schoolDomain}.`)
      if (users.some((account) => account.studentNumber === studentNumber)) return setAuthError('Ese número de control ya está registrado.')
    }
    const newAccount = { name, email, studentNumber: registerAsPlantel ? studentNumber : '', tipo: registerAsPlantel ? 'plantel' : 'otro', password: await hashPassword(password) }
    setUsers((current) => [...current, newAccount])
    setUser(newAccount)
    writeStorage('rt_ses', newAccount.email)
    setModal('')
    setToast('Tu cuenta está lista.')
  }

  function signOut() {
    writeStorage('rt_ses', null)
    setUser(null)
    setModal('')
    setToast('Cerraste sesión.')
  }

  function scrollProducts(direction) {
    carouselRef.current?.scrollBy({ left: direction * 360, behavior: 'smooth' })
  }

  function changeCart(productId, delta) {
    const product = productsWithInventory.find((item) => item.id === productId)
    if (!product) return
    setCart((current) => {
      const quantity = Math.min(product.stock, Math.max(0, (current[productId] || 0) + delta))
      const next = { ...current }
      if (quantity) next[productId] = quantity
      else delete next[productId]
      return next
    })
  }

  function confirmOrder(event) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const contact = String(form.get('contact')).trim()
    const order = {
      id: makeRecordId('P').slice(-7), em: user?.email || contact,
      nom: String(form.get('name')).trim(), tel: contact,
      items: cartItems.map((item) => ({ id: item.id, n: item.name, p: item.price, q: item.quantity })),
      total: cartTotal, pago: selectedPayment, estado: 'Pendiente', ts: Number(makeRecordId('')),
    }
    setOrders((current) => [order, ...current])
    setPendingOrder(order)
    setInventory((current) => Object.fromEntries(cartItems.map((item) => [item.id, { ...(current[item.id] || {}), s: item.stock - item.quantity }])))
    setCart({})
    addNotice('admin', `Nuevo apartado ${order.id} de ${order.nom}: ${formatMoney(order.total)}`)
  }

  function saveMoneyDonation(event) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const amount = Math.floor(Number(form.get('amount')))
    if (!(amount >= 10)) {
      setDonationAmountError('La aportación mínima es de $10 MXN.')
      return
    }
    const timestamp = Number(makeRecordId(''))
    const record = { id: `A${timestamp}`, amount, method: String(form.get('method')), name: String(form.get('name')).trim(), email: String(form.get('email')).trim(), status: 'Intención registrada; pago pendiente', ts: timestamp }
    setMoneyDonations((current) => [record, ...current])
    addNotice('admin', `Nueva intención de aportación de ${formatMoney(amount)}.`)
    setDonationComplete(true)
    setDonationAmountError('')
  }

  function openPhysicalDonation() {
    setPhysicalComplete(false)
    setModal('physical')
  }

  function savePhysicalDonation(event) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const record = {
      id: makeRecordId('D'), nom: String(form.get('fullName')).trim(), dir: String(form.get('address')).trim(),
      tel: String(form.get('phone')).replace(/\D/g, ''), n: Math.floor(Number(form.get('quantity'))),
      em: user?.email || '', ts: Date.now(), est: 'Pendiente',
    }
    setPhysicalDonations((current) => [record, ...current])
    addNotice('admin', `Nueva donación de ${record.n} cuaderno(s) de ${record.nom}.`)
    setPhysicalComplete(true)
  }

  async function resizePhoto(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onerror = reject
      reader.onload = () => {
        const image = new Image()
        image.onerror = reject
        image.onload = () => {
          const scale = Math.min(1, 720 / Math.max(image.width, image.height))
          const canvas = document.createElement('canvas')
          canvas.width = Math.round(image.width * scale)
          canvas.height = Math.round(image.height * scale)
          canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height)
          resolve(canvas.toDataURL('image/jpeg', 0.72))
        }
        image.src = reader.result
      }
      reader.readAsDataURL(file)
    })
  }

  async function publishPost(event) {
    event.preventDefault()
    if (!requireMember()) return
    const form = event.currentTarget
    const values = new FormData(form)
    const file = values.get('photo')
    if (!(file instanceof File) || !file.size) {
      setPostError('Agrega una foto del artículo.')
      return
    }
    const name = String(values.get('name')).trim()
    const description = String(values.get('description')).trim()
    const exchange = String(values.get('exchange') || '').trim()
    const timestamp = Number(makeRecordId(''))
    const reasons = []
    if (filteredWords.test(`${name} ${description} ${exchange}`)) reasons.push('El texto contiene palabras no permitidas')
    if (/https?:|www\.|\.com\b|\d{10}/i.test(`${name} ${description} ${exchange}`)) reasons.push('Incluye enlaces o teléfonos')
    if (name.length < 4) reasons.push('El nombre es muy corto')
    try {
      const image = await resizePhoto(file)
      const pending = reasons.length > 0
      const post = {
        id: `p${timestamp}`, n: name, c: String(values.get('category')), t: String(values.get('type')),
        tam: String(values.get('size') || '').trim(), uso: String(values.get('condition')),
        d: description, cambio: exchange, img: image, by: user.name, email: user.email,
        ts: timestamp, com: [], status: pending ? 'review' : 'ok', exp: pending ? timestamp + day : null,
        why: reasons.join('. '),
      }
      setPosts((current) => [post, ...current])
      if (pending) addNotice('admin', `Nueva publicación por revisar: “${post.n}”.`)
      setPostError('')
      setUploadPreview('')
      form.reset()
      setToast(pending ? 'Tu publicación quedó en revisión.' : 'Tu artículo ya está publicado.')
      if (!pending) navigate('catalogo')
    } catch {
      setPostError('No pudimos leer esa imagen. Prueba con otro archivo.')
    }
  }

  function addPostComment(event) {
    event.preventDefault()
    if (!requireMember() || !activePost) return
    const form = new FormData(event.currentTarget)
    const comment = { n: user.name, k: String(form.get('interest')), t: String(form.get('comment')).trim(), ts: Number(makeRecordId('')) }
    setPosts((current) => current.map((post) => post.id === activePost.id ? { ...post, com: [...(post.com || []), comment] } : post))
    if (activePost.email !== user.email) addNotice(activePost.email, `${user.name} escribió en “${activePost.n}”.`)
    event.currentTarget.reset()
    setToast('Comentario agregado al muro.')
  }

  function submitNeed(event) {
    event.preventDefault()
    if (!requireMember()) return
    const form = new FormData(event.currentTarget)
    const timestamp = Number(makeRecordId(''))
    const request = { id: `R${timestamp}`, que: String(form.get('need')).trim(), via: String(form.get('contact')), nom: user.name, em: user.email, ts: timestamp, at: false }
    setRequests((current) => [request, ...current])
    addNotice('admin', `Nueva solicitud privada de ${user.name}.`)
    event.currentTarget.reset()
    setToast('Solicitud enviada de forma privada.')
  }

  function submitGeneralComment(event) {
    event.preventDefault()
    if (!requireMember()) return
    const form = new FormData(event.currentTarget)
    setComments((current) => [{ n: user.name, t: String(form.get('comment')).trim(), ts: Number(makeRecordId('')) }, ...current])
    event.currentTarget.reset()
    setToast('Gracias por compartir tu comentario.')
  }

  function updatePost(id, status) {
    const post = posts.find((item) => item.id === id)
    setPosts((current) => current.map((item) => item.id === id ? { ...item, status } : item))
    if (post) addNotice(post.email, status === 'ok' ? `Tu publicación “${post.n}” fue aprobada.` : `Tu publicación “${post.n}” no fue aprobada.`)
    setToast(status === 'ok' ? 'Publicación aprobada.' : 'Publicación rechazada.')
  }

  function updateOrder(id, status) {
    setOrders((current) => current.map((order) => order.id === id ? { ...order, estado: status } : order))
    setToast('Estado del pedido actualizado.')
  }

  function updateDonation(id, status) {
    setPhysicalDonations((current) => current.map((donation) => donation.id === id ? { ...donation, est: status } : donation))
    setToast('Donación actualizada.')
  }

  function markNoticesRead() {
    setNotices((current) => current.map((notice) => notice.to === user?.email || (isAdmin && notice.to === 'admin') ? { ...notice, read: true } : notice))
    setModal('notices')
  }

  function showPolicy(key) {
    setLegalPage(key)
    setView('legal')
    setModal('legal')
  }

  const filteredPosts = visiblePosts.filter((post) => {
    const matchesCategory = selectedCategory === 'Todo' || post.c === selectedCategory
    const matchesType = postTypeFilter === 'Todo' || post.t === postTypeFilter
    const matchesSearch = !search || normalize(`${post.n} ${post.c} ${post.d}`).includes(normalize(search))
    return matchesCategory && matchesType && matchesSearch
  })

  function productCard(product, compact = false) {
    return <article className={`notebook-card ${compact ? 'notebook-card-compact' : ''}`} key={product.id}>
      <button className="notebook-image" onClick={() => navigate('cuadernos')} aria-label={`Ver ${product.name}`}>
        <Picture image={product.image} alt={`Libreta artesanal ${product.design}`} />
        <span className="notebook-size">{product.id.endsWith('-ch') ? 'Tamaño chico' : 'Tamaño grande'}</span>
      </button>
      <div className="notebook-info"><div><h3>{product.name}</h3><span>{formatMoney(product.price)}</span></div><p>{product.detail}</p><small className="availability">{product.stock ? `${product.stock} disponibles` : 'Agotado'}</small><button className="add-button" disabled={!product.stock} onClick={() => { changeCart(product.id, 1); setToast('Apartado provisional agregado al carrito.') }}><Plus size={16} /> Apartar cuaderno</button></div>
    </article>
  }

  function postCard(post) {
    return <article className="exchange-card" key={post.id}>
      <button className="exchange-image" onClick={() => navigate(`post-${post.id}`)} aria-label={`Ver ${post.n}`}>
        <img src={post.img} alt={post.n} />
        {post.status === 'review' && <span className="review-badge">En revisión</span>}
      </button>
      <div className="exchange-info"><div className="exchange-topline"><span>{post.c}</span><span className={post.t === 'Donación' ? 'type-tag gift-tag' : 'type-tag exchange-tag'}>{post.t}</span></div><h3>{post.n}</h3><p>{post.uso}{post.tam ? ` · Talla ${post.tam}` : ''}</p><button className="subtle-link" onClick={() => navigate(`post-${post.id}`)}>Ver publicación <ArrowRight size={14} /></button></div>
    </article>
  }

  function pageTitle(eyebrow, title, copy = '') {
    return <header className="page-heading"><span className="eyebrow">{eyebrow}</span><h1>{title}</h1>{copy && <p>{copy}</p>}</header>
  }

  const homePage = <>
    <section className="school-hero">
      <div className="school-hero-copy"><span className="eyebrow"><Leaf size={14} /> Iniciativa estudiantil · CBTis 122</span><h1>Detrás de cada donación hay una oportunidad.</h1><p>EcoCambio conecta materiales que todavía sirven con estudiantes que pueden aprovecharlos. Reutilizamos, compartimos y aprendemos a cuidar lo que tenemos.</p><div className="hero-buttons"><button className="primary-button" onClick={() => navigate('publico')}>Conoce nuestra causa <ArrowRight size={17} /></button><button className="plain-button" onClick={() => { setAuthMode('login'); setAuthNotice('Ingresa con tu correo institucional para participar en la comunidad escolar.'); setModal('auth') }}>Espacio CBTis <LockKeyhole size={15} /></button></div><div className="hero-promise"><span><BadgeCheck size={16} /> ODS 12 · Consumo responsable</span><span><BookOpen size={16} /> Apoyo entre estudiantes</span></div></div>
      <div className="school-hero-art"><Picture image="photo-1503676260728-1c00da094a0b" alt="Estudiantes aprendiendo juntos" className="hero-school-photo" /><div className="hero-image-note"><Leaf size={18} /><span>Compartir también<br />es aprender.</span></div><div className="hero-photo-caption">EcoCambio · CBTis 122</div></div>
    </section>
    <section className="home-notebooks"><div className="section-heading-row"><div><span className="eyebrow">CUADERNOS CON CAUSA</span><h2>Una nueva portada.<br /><em>Un comienzo nuevo.</em></h2><p>Libretas artesanales hechas con hojas recuperadas del plantel.</p></div><div className="carousel-arrows"><button aria-label="Libretas anteriores" onClick={() => scrollProducts(-1)}><ChevronLeft size={19} /></button><button aria-label="Más libretas" onClick={() => scrollProducts(1)}><ChevronRight size={19} /></button></div></div><div className="notebook-carousel" ref={carouselRef}>{productsWithInventory.map((product) => productCard(product, true))}</div><div className="carousel-bottom"><span>Cada portada tiene su propia historia.</span><button className="subtle-link" onClick={() => navigate('cuadernos')}>Ver todas las libretas <ArrowRight size={14} /></button></div></section>
    <section className="home-about" id="home-about"><div className="about-image"><Picture image="photo-1516321318423-f06f85e504b3" alt="Estudiantes colaborando en un proyecto" /><span>Un proyecto de nuestra comunidad.</span></div><div className="about-copy"><span className="eyebrow">¿QUÉ ES ECOCAMBIO?</span><h2>Compartimos lo que tenemos para que nadie se quede sin lo que necesita.</h2><p>EcoCambio nació en el CBTis 122 para reducir el desperdicio de materiales escolares y convertir la solidaridad cotidiana en oportunidades para seguir estudiando.</p><button className="subtle-link" onClick={() => navigate('nosotros')}>Quiénes somos <ArrowRight size={14} /></button></div></section>
    <section className="access-choices"><div><span className="eyebrow">DOS FORMAS DE PARTICIPAR</span><h2>Un mismo propósito, espacios distintos.</h2><p>Conoce la iniciativa desde cualquier lugar o entra al espacio escolar para compartir materiales con la comunidad CBTis 122.</p></div><div className="access-choice-grid"><article className="public-choice"><span className="access-icon"><Heart size={20} /></span><small>ABIERTO A TODAS LAS PERSONAS</small><h3>Espacio público</h3><p>Conoce la causa, cómo donar materiales y el proyecto de libretas artesanales.</p><button className="subtle-link" onClick={() => navigate('publico')}>Conocer cómo ayudar <ArrowRight size={14} /></button></article><article className="school-choice"><span className="access-icon"><LockKeyhole size={19} /></span><small>ESTUDIANTES Y PERSONAL DEL CBTis 122</small><h3>Comunidad escolar</h3><p>Consulta donaciones, intercambios y solicitudes privadas del plantel.</p><button className="subtle-link" onClick={() => { setAuthMode('login'); setAuthNotice('Usa tu correo institucional del CBTis 122 para acceder.'); setModal('auth') }}>Entrar al CBTis 122 <ArrowRight size={14} /></button></article></div></section>
    <section className="cause-progress-home"><div><span className="eyebrow">CUADERNOS CON CAUSA</span><h2>Un cuaderno puede acercarnos a una computadora.</h2><p>Recuperamos hojas útiles, elaboramos libretas a mano y reunimos recursos para una computadora portátil destinada a apoyar la continuidad escolar.</p><button className="subtle-link" onClick={() => navigate('cuadernos')}>Conoce el proceso <ArrowRight size={14} /></button></div><ProgressMeter raised={receivedAmount} target={Number(meta) || 10000} /></section>
    <section className="home-actions"><span className="eyebrow">PARTICIPA A TU MANERA</span><div><button onClick={() => navigate('publicar')}><Plus size={18} /><span><b>Comparte un artículo</b><small>Publica una donación o un intercambio.</small></span><ArrowRight size={16} /></button><button onClick={() => navigate('necesito')}><CircleHelp size={18} /><span><b>¿Necesitas algo?</b><small>Cuéntaselo al comité de forma privada.</small></span><ArrowRight size={16} /></button><button onClick={() => navigate('dona-cuadernos')}><Heart size={18} /><span><b>Dona cuadernos usados</b><small>Van directo al proyecto, no a la venta.</small></span><ArrowRight size={16} /></button></div></section>
  </>

  return <div className="reto-app">
    <div className="top-ribbon"><Leaf size={13} /> Una comunidad que da otra vuelta a las cosas</div>
    <header className="apple-header">
      <Link className="reto-brand" to="/" aria-label="EcoCambio, inicio"><span className="reto-logo"><Leaf size={21} /></span><span><b>EcoCambio</b><small>CBTis 122 · ODS 12</small></span></Link>
      <button className="mobile-menu-button" aria-label="Abrir navegación" onClick={() => setMenuOpen((open) => !open)}>{menuOpen ? <X size={20} /> : <Menu size={20} />}</button>
      <nav className={`top-nav ${menuOpen ? 'top-nav-open' : ''}`} aria-label="Principal">
        <a className={view === 'inicio' ? 'nav-current' : ''} href="#inicio">Inicio</a>
        <a className={view === 'publico' ? 'nav-current' : ''} href="#publico">Espacio público</a>
        <a className={view === 'catalogo' || view === 'post' || view === 'publicar' ? 'nav-current' : ''} href="#catalogo">Catálogo escolar</a>
        <a className={view === 'cuadernos' ? 'nav-current' : ''} href="#cuadernos">Cuadernos con causa</a>
        <Link className={view === 'nosotros' ? 'nav-current' : ''} to="/quienes-somos">Quiénes somos</Link>
        <div className="more-menu"><button aria-expanded={moreOpen} onClick={() => setMoreOpen((open) => !open)}>Comunidad <ChevronDown size={13} /></button>{moreOpen && <div className="more-dropdown"><a href="#publicar">Publicar artículo</a><a href="#necesito">Lo necesito</a><a href="#comentarios">Comentarios</a><a href="#pedidos">Mis pedidos</a><a href="#dona-cuadernos">Donar cuadernos</a><a href="#donar">Donación económica</a></div>}</div>
        {isAdmin && <a className={view === 'admin' ? 'nav-current' : ''} href="#admin">Administración</a>}
      </nav>
      <div className="top-actions"><button className="header-icon" aria-label="Avisos" onClick={user ? markNoticesRead : () => { setAuthNotice('Inicia sesión para consultar tus avisos.'); setModal('auth') }}><MessageCircle size={18} />{unreadNotices.length > 0 && <i />}</button><button className="header-icon cart-icon" aria-label={`Carrito (${cartCount})`} onClick={() => setModal('cart')}><ShoppingBag size={19} />{cartCount > 0 && <b>{cartCount}</b>}</button>{user ? <button className="account-button" onClick={signOut} title="Cerrar sesión"><span className="account-avatar">{initials(user.name)}</span><span className="account-label">{user.name.split(' ')[0]}<small>{isAdmin ? 'Administración' : 'CBTis 122'}</small></span><LogIn size={15} className="logout-icon" /></button> : <Link className="signin-button" to="/login"><LockKeyhole size={15} /> Espacio CBTis</Link>}</div>
    </header>

    <main className={`main-content ${needsSchoolAccess ? 'access-locked' : ''}`}>
      {needsSchoolAccess && <section className="content-page access-gate-page"><div className="access-gate-card"><span className="access-icon"><LockKeyhole size={21} /></span><span className="eyebrow">ESPACIO EXCLUSIVO CBTis 122</span><h1>Este espacio es para la comunidad escolar.</h1><p>Inicia sesión con tu correo institucional para consultar donaciones e intercambios, publicar artículos y enviar solicitudes privadas. El espacio público y Cuadernos con Causa están abiertos a todas las personas.</p><div className="hero-buttons"><button className="primary-button" onClick={() => { setAuthMode('login'); setAuthNotice('Usa tu correo institucional del CBTis 122 para continuar.'); setModal('auth') }}>Entrar con correo CBTis <LockKeyhole size={15} /></button><button className="plain-button" onClick={() => navigate('publico')}>Ir al espacio público <ArrowRight size={15} /></button></div></div></section>}
      {view === 'inicio' && homePage}

      {view === 'publico' && <PublicSpace pageTitle={pageTitle} onDonate={openPhysicalDonation} onCause={() => navigate('cuadernos')} onMoney={() => navigate('donar')} raised={receivedAmount} target={Number(meta) || 10000} />}

      {view === 'nosotros' && <section className="content-page about-page">
        {pageTitle('NUESTRA HISTORIA', '¿Qué es EcoCambio?', 'Un proyecto estudiantil del CBTis 122 para compartir recursos escolares y aprovechar mejor los cuadernos que todavía tienen hojas útiles.')}
        <div className="about-feature"><Picture image="photo-1529390079861-591de354faf5" alt="Grupo de estudiantes colaborando" /><div><span className="eyebrow">CÓMO NACIÓ</span><h2>Una idea sencilla: que lo útil no se quede guardado.</h2><p>En la escuela a veces tenemos materiales que ya no ocupamos, mientras a alguien más le hacen falta. EcoCambio nació para conectar esas dos situaciones en un espacio de confianza y cuidado entre estudiantes.</p><p>Además, reunimos cuadernos usados con hojas aprovechables para transformarlos en libretas artesanales. Así, cada hoja puede continuar acompañando nuevas clases, apuntes e ideas.</p></div></div>
        <div className="mission-columns"><article><span>01</span><h3>Nuestra misión</h3><p>Facilitar la donación y el intercambio de artículos escolares, y dar un nuevo uso a cuadernos que aún pueden aprovecharse.</p></article><article><span>02</span><h3>Nuestra visión</h3><p>Una comunidad escolar donde pedir, compartir y reutilizar materiales sea sencillo, digno y parte de la vida diaria.</p></article><article><span>03</span><h3>Lo que queremos lograr</h3><p>Que más estudiantes encuentren lo que necesitan y que las libretas artesanales contribuyan a la meta solidaria del proyecto.</p></article></div>
        <div className="about-values"><h2>¿Por qué participar?</h2><p>Porque compartir materiales reduce el desperdicio y ayuda a que el acceso a útiles no dependa únicamente de comprar algo nuevo. Una donación, un intercambio o una solicitud también fortalecen la comunidad que hacemos en el CBTis 122.</p><button className="primary-button" onClick={() => navigate('catalogo')}>Explorar el catálogo <ArrowRight size={16} /></button></div>
      </section>}

      {view === 'catalogo' && canParticipate && <section className="content-page catalog-page">
        {pageTitle('MARKETPLACE ESCOLAR', 'Catálogo de la comunidad', 'Mochilas, uniformes, libros y otros artículos compartidos por estudiantes del CBTis 122.')}
        <div className="catalog-notice"><BookOpen size={17} /><span>Las entregas se coordinan en la biblioteca del CBTis 122. Participación exclusiva de la comunidad del plantel.</span></div>
        <p className="local-storage-note">Versión de demostración: publicaciones y solicitudes se guardan en este navegador; todavía no se comparten entre cuentas o dispositivos.</p>
        <div className="catalog-tools"><label className="search-box"><Search size={17} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Buscar artículos" /></label><div className="segmented-control" aria-label="Tipo de publicación">{['Todo', 'Donación', 'Intercambio'].map((type) => <button key={type} className={postTypeFilter === type ? 'selected' : ''} onClick={() => setPostTypeFilter(type)}>{type}</button>)}</div><button className="primary-button" onClick={() => { setPostError(''); navigate('publicar') }}><Plus size={16} /> Publicar</button></div>
        <div className="category-list">{categories.map((category) => <button key={category} className={selectedCategory === category ? 'category-active' : ''} onClick={() => setSelectedCategory(category)}>{category}</button>)}</div>
        <div className="exchange-grid">{filteredPosts.length ? filteredPosts.map(postCard) : <div className="empty-state"><span><Search size={20} /></span><h2>No encontramos publicaciones.</h2><p>Prueba otra categoría o comparte un artículo que le pueda servir a alguien.</p><button className="subtle-link" onClick={() => navigate('publicar')}>Publicar un artículo <ArrowRight size={14} /></button></div>}</div>
      </section>}

      {view === 'publicar' && canParticipate && <section className="content-page publish-page">
        <div className="publish-intro">{pageTitle('COMPARTE CON LA COMUNIDAD', 'Publicar un artículo', 'Dona algo que ya no necesitas o intercámbialo por lo que te hace falta.')}
          <ol className="process-steps"><li><span>1</span>Elige donación o intercambio.</li><li><span>2</span>Cuéntanos cómo está y agrega una foto real.</li><li><span>3</span>Acuerden la entrega en la biblioteca.</li></ol><div className="catalog-notice"><ShieldCheck size={17} /><span>Las publicaciones que necesiten revisión quedan pendientes hasta 24 horas.</span></div>
        </div>
        <form className="form-panel" onSubmit={publishPost}>
          <div className="type-picker"><button type="button" className="type-option selected" onClick={(event) => { event.currentTarget.parentElement.querySelectorAll('button').forEach((button) => button.classList.remove('selected')); event.currentTarget.classList.add('selected'); event.currentTarget.parentElement.nextElementSibling.value = 'Donación' }}><Heart size={17} /><b>Donar</b><small>Lo compartes sin costo.</small></button><button type="button" className="type-option" onClick={(event) => { event.currentTarget.parentElement.querySelectorAll('button').forEach((button) => button.classList.remove('selected')); event.currentTarget.classList.add('selected'); event.currentTarget.parentElement.nextElementSibling.value = 'Intercambio' }}><ArrowRight size={17} /><b>Intercambiar</b><small>Buscas algo a cambio.</small></button></div><input name="type" type="hidden" value="Donación" />
          <label>Nombre del artículo<input name="name" required maxLength="60" placeholder="Ej. Sudadera gris talla M" /></label><div className="form-row"><label>Categoría<select name="category">{categories.slice(1).map((category) => <option key={category}>{category}</option>)}</select></label><label>Estado<select name="condition"><option>Como nuevo</option><option>Poco uso</option><option>Uso medio</option><option>Con detalles</option></select></label></div>
          <label>Talla, si aplica<input name="size" maxLength="10" placeholder="M, 28, G..." /></label><label>Descripción<textarea name="description" rows="3" maxLength="300" placeholder="Color, materia, detalles que quieras compartir" /></label><label className="exchange-detail-label">¿Qué te gustaría recibir a cambio?<input name="exchange" maxLength="80" placeholder="Ej. Un libro de Física" /></label>
          <label className="upload-field">Foto del artículo<input name="photo" type="file" accept="image/*" required onChange={async (event) => { const file = event.target.files?.[0]; if (file) setUploadPreview(await resizePhoto(file)) }} /><span className="upload-hint">{uploadPreview ? 'Foto lista para publicar' : 'Elige una imagen de tu dispositivo'}</span></label>{uploadPreview && <img className="upload-preview" src={uploadPreview} alt="Vista previa del artículo" />}
          {postError && <p className="form-error" role="alert">{postError}</p>}<button className="primary-button form-submit" type="submit" disabled={!user}>Publicar artículo <ArrowRight size={16} /></button>{!user && <button className="subtle-link" type="button" onClick={() => { setAuthNotice('Inicia sesión con tu cuenta del plantel para publicar.'); setModal('auth') }}>Iniciar sesión para publicar <LogIn size={14} /></button>}
        </form>
      </section>}

      {view === 'post' && <section className="content-page post-page"><button className="back-link" onClick={() => navigate('catalogo')}><ArrowLeft size={15} /> Volver al catálogo</button>{activePost ? <><div className="post-detail"><img src={activePost.img} alt={activePost.n} /><div className="post-detail-copy"><span className={activePost.t === 'Donación' ? 'type-tag gift-tag' : 'type-tag exchange-tag'}>{activePost.t}</span>{activePost.status === 'review' && <span className="type-tag pending-tag">En revisión</span>}<h1>{activePost.n}</h1><dl><dt>Categoría</dt><dd>{activePost.c}</dd>{activePost.tam && <><dt>Talla</dt><dd>{activePost.tam}</dd></>}<dt>Estado</dt><dd>{activePost.uso}</dd><dt>Detalles</dt><dd>{activePost.d || 'Sin más detalles.'}</dd>{activePost.t === 'Intercambio' && activePost.cambio && <><dt>A cambio de</dt><dd>{activePost.cambio}</dd></>}<dt>Publicó</dt><dd>{activePost.by} · {formatDate(activePost.ts)}</dd><dt>Entrega</dt><dd>Biblioteca del CBTis 122</dd></dl></div></div><section className="wall-section"><div><span className="eyebrow">MURO DE LA PUBLICACIÓN</span><h2>Conversación</h2>{(activePost.com || []).length ? activePost.com.map((comment, index) => <article className="comment-entry" key={`${comment.ts}-${index}`}><span className="small-avatar">{initials(comment.n)}</span><div><b>{comment.n}</b><small>{comment.k} · {formatDate(comment.ts)}</small><p>{comment.t}</p></div></article>) : <p className="quiet-copy">Todavía no hay comentarios. Puedes iniciar la conversación.</p>}</div><form className="form-panel wall-form" onSubmit={addPostComment}><label>¿En qué te interesa?<select name="interest"><option>Me interesa</option><option>Tengo una pregunta</option><option>Quiero intercambiarlo</option></select></label><label>Comentario<textarea name="comment" required maxLength="200" rows="4" /></label><button className="primary-button" disabled={!user}>Comentar <ArrowRight size={15} /></button></form></section></> : <EmptyState title="La publicación ya no está disponible." action={() => navigate('catalogo')} actionText="Volver al catálogo" />}</section>}

      {view === 'cuadernos' && <section className="content-page store-page">{pageTitle('PAPEL RECUPERADO · PROPÓSITO SOLIDARIO', 'Cuadernos con causa', 'No es una tienda cualquiera: cada libreta nace de materiales recuperados y ayuda a acercarnos a una meta educativa.')}
        <div className="campaign-intro"><div><span className="eyebrow">UNA LIBRETA, UNA NUEVA OPORTUNIDAD</span><h2>Hojas que vuelven.<br /><em>Oportunidades que siguen.</em></h2><p>Recibimos cuadernos con hojas limpias, recuperamos el papel útil y lo encuadernamos en libretas artesanales. Los recursos de su venta se destinan a reunir $10,000 MXN para adquirir una computadora portátil que apoye a una persona que la necesite para continuar sus estudios.</p><div className="hero-buttons"><button className="primary-button" onClick={openPhysicalDonation}>Donar cuadernos usados <Heart size={16} /></button><button className="plain-button" onClick={() => navigate('publico')}>Conocer la causa <ArrowRight size={15} /></button></div></div><ProgressMeter raised={receivedAmount} target={Number(meta) || 10000} /></div>
        <div className="recovery-steps"><article><span>01</span><h3>Recibimos</h3><p>Cuadernos usados que todavía tienen hojas limpias y aprovechables.</p></article><article><span>02</span><h3>Rescatamos</h3><p>Seleccionamos las hojas en buen estado y preparamos el material.</p></article><article><span>03</span><h3>Encuadernamos</h3><p>Armamos libretas a mano con portadas cuidadas y espiral o alambre.</p></article><article><span>04</span><h3>Apoyamos</h3><p>Reunimos los recursos para la computadora portátil de la meta solidaria.</p></article></div>
        <div className="section-heading-row store-heading"><div><span className="eyebrow">CATÁLOGO DE LIBRETAS</span><h2>Encuentra tu portada.</h2></div><div className="carousel-arrows"><button aria-label="Productos anteriores" onClick={() => scrollProducts(-1)}><ChevronLeft size={19} /></button><button aria-label="Más productos" onClick={() => scrollProducts(1)}><ChevronRight size={19} /></button></div></div><div className="notebook-carousel full-carousel" ref={carouselRef}>{productsWithInventory.map((product) => productCard(product))}</div>
        <div className="donation-separation"><div><span className="eyebrow">SON CAMINOS DISTINTOS</span><h2>Comprar una libreta no es lo mismo que donar cuadernos.</h2><p>Las donaciones de cuadernos van directamente al proyecto y nunca aparecen a la venta.</p></div><button className="secondary-button" onClick={openPhysicalDonation}>Registrar donación física <ArrowRight size={15} /></button></div>
      </section>}

      {view === 'donar' && <section className="content-page donation-page">{pageTitle('APORTACIÓN ECONÓMICA', 'Apoya a EcoCambio', 'Esta aportación es independiente de comprar una libreta o donar cuadernos físicos.')}{donationComplete ? <div className="success-panel"><span><Check size={24} /></span><h2>Gracias por tu apoyo.</h2><p>Registramos tu intención de aportar en este navegador. No se envió al equipo ni se realizó ningún cobro; falta integrar una pasarela y un servicio de recepción.</p><button className="primary-button" onClick={() => { setDonationComplete(false); setDonationAmount('') }}>Registrar otra aportación</button></div> : <form className="form-panel donation-form" onSubmit={saveMoneyDonation}><p>Elige una cantidad sugerida o escribe cualquier otra cantidad en pesos.</p><div className="amount-pills">{suggestedAmounts.map((amount) => <button type="button" key={amount} className={Number(donationAmount) === amount ? 'amount-selected' : ''} onClick={() => { setDonationAmount(String(amount)); setDonationAmountError('') }}>{formatMoney(amount)}</button>)}</div><label>Otra cantidad<input name="amount" type="number" min="10" step="1" value={donationAmount} onChange={(event) => setDonationAmount(event.target.value)} placeholder="Escribe la cantidad en MXN" required /></label><label>Nombre<input name="name" autoComplete="name" minLength="3" required /></label><label>Correo electrónico<input name="email" type="email" autoComplete="email" required /></label><label>Método de pago previsto<select name="method"><option>Mercado Pago</option><option>PayPal</option><option>Tarjeta mediante pasarela</option></select></label>{donationAmountError && <p className="form-error" role="alert">{donationAmountError}</p>}<p className="secure-note"><ShieldCheck size={16} /> No se cobran ni se guardan datos bancarios aquí. El pago queda pendiente hasta configurar la pasarela.</p><button className="primary-button" type="submit">Continuar con mi aportación <ArrowRight size={16} /></button></form>}</section>}

      {view === 'dona-cuadernos' && <section className="content-page physical-page">{pageTitle('DONACIÓN FÍSICA', 'Dona tus cuadernos', 'Los cuadernos con hojas útiles se reúnen para crear libretas artesanales. No se publican en el catálogo escolar ni se venden como donaciones.')}
        <div className="physical-feature"><div className="physical-icon"><BookOpen size={25} /></div><div><b>Solo necesitamos cuatro datos</b><p>Nombre completo, dirección, teléfono y cantidad de cuadernos. El comité podrá coordinar contigo la recepción.</p></div><button className="primary-button" onClick={openPhysicalDonation}>Abrir formulario <ArrowRight size={15} /></button></div>
      </section>}

      {view === 'necesito' && <section className="content-page need-page"><div>{pageTitle('SOLICITUD PRIVADA', '¿Necesitas algo? Pídelo sin pena.', 'Tu solicitud llega al comité. No se publica en el catálogo ni se muestra a otros estudiantes.')}
        <ol className="process-steps"><li><span>1</span>Cuéntanos qué artículo buscas.</li><li><span>2</span>El comité revisa las donaciones disponibles.</li><li><span>3</span>Te contactamos para coordinar.</li></ol></div><form className="form-panel" onSubmit={submitNeed}><label>¿Qué necesitas?<input name="need" required maxLength="120" placeholder="Ej. Uniforme deportivo talla M" /></label><label>¿Cómo te contactamos?<select name="contact"><option>Que me busque un maestro</option><option>Por WhatsApp</option><option>Por correo institucional</option></select></label><button className="primary-button" disabled={!user}>Enviar solicitud privada <ArrowRight size={15} /></button>{!user && <p className="quiet-copy">Inicia sesión con una cuenta del plantel para enviar tu solicitud.</p>}</form></section>}

      {view === 'comentarios' && <section className="content-page comments-page">{pageTitle('ESCUCHAMOS A LA COMUNIDAD', 'Comentarios', 'Cuéntanos qué te parece EcoCambio o qué podríamos mejorar.')}
        <div className="wall-section"><div>{comments.length ? comments.map((comment, index) => <article className="comment-entry" key={`${comment.ts}-${index}`}><span className="small-avatar">{initials(comment.n)}</span><div><b>{comment.n}</b><small>{formatDate(comment.ts)}</small><p>{comment.t}</p></div></article>) : <div className="quiet-panel">Todavía no hay comentarios. Cuando quieras, puedes abrir la conversación.</div>}</div><form className="form-panel" onSubmit={submitGeneralComment}><label>Tu comentario<textarea name="comment" required maxLength="300" rows="5" /></label><button className="primary-button" disabled={!user}>Publicar comentario <ArrowRight size={15} /></button>{!user && <p className="quiet-copy">Inicia sesión con una cuenta del plantel para comentar.</p>}</form></div>
      </section>}

      {view === 'pedidos' && <section className="content-page orders-page">{pageTitle(isAdmin ? 'GESTIÓN DE APARTADOS' : 'TU ACTIVIDAD', isAdmin ? 'Apartados de libretas' : 'Mis apartados', isAdmin ? 'Los apartados esperan confirmación de disponibilidad; no representan pagos recibidos.' : 'Consulta aquí el estado de tus apartados de libretas.')}
        {isAdmin && <div className="inventory-panel"><div className="inventory-title"><div><span className="eyebrow">SOLO ADMINISTRACIÓN</span><h2>Inventario y avance verificado</h2></div></div><div className="campaign-admin-fields"><label>Meta estimada (MXN)<input type="number" min="1" value={meta} onChange={(event) => setMeta(Number(event.target.value) || 10000)} /></label><label>Total verificado hasta ahora (MXN)<input type="number" min="0" value={verifiedRaised} onChange={(event) => setVerifiedRaised(Math.max(0, Number(event.target.value) || 0))} /></label><p>El avance público usa solo este monto, no pedidos pendientes ni intenciones de donación.</p></div><div className="inventory-grid">{productsWithInventory.map((product) => <label key={product.id}>{product.name}<span><input type="number" min="0" value={product.price} onChange={(event) => setInventory((current) => ({ ...current, [product.id]: { ...(current[product.id] || {}), p: Number(event.target.value) } }))} aria-label={`Precio de ${product.name}`} /><input type="number" min="0" value={product.stock} onChange={(event) => setInventory((current) => ({ ...current, [product.id]: { ...(current[product.id] || {}), s: Number(event.target.value) } }))} aria-label="Existencias" /></span></label>)}</div></div>}
        <div className="record-list">{(isAdmin ? orders : orders.filter((order) => order.em === user?.email)).length ? (isAdmin ? orders : orders.filter((order) => order.em === user?.email)).map((order) => <article className="record-row" key={order.id}><div><b>Pedido {order.id}</b><span className={`status-pill status-${normalize(order.estado)}`}>{order.estado}</span><p>{order.items.map((item) => `${item.q} × ${item.n}`).join(', ')}</p><small>{formatDate(order.ts)} · {order.pago}{isAdmin ? ` · ${order.nom} · ${order.tel}` : ''}</small></div><div className="record-actions"><strong>{formatMoney(order.total)}</strong>{isAdmin && <><button onClick={() => updateOrder(order.id, 'Pagado')} disabled={order.estado !== 'Pendiente'}>Marcar pagado</button><button onClick={() => updateOrder(order.id, 'Entregado')} disabled={order.estado === 'Entregado'}>Marcar entregado</button><button className="danger-action" onClick={() => updateOrder(order.id, 'Cancelado')}>Cancelar</button></>}</div></article>) : <EmptyState title="Todavía no hay pedidos." copy="Las compras de libretas aparecerán aquí cuando confirmes un pedido." action={() => navigate('cuadernos')} actionText="Ver libretas" />}</div>
      </section>}

      {view === 'pedido' && <section className="content-page checkout-page">{pageTitle('APARTADO DE LIBRETAS', 'Revisa tu selección', 'Puedes apartar una libreta sin crear cuenta. El apartado se guarda solo en este navegador; no se envía al equipo ni genera un cobro hasta integrar un backend y una pasarela oficial.')}{cartItems.length ? <div className="checkout-layout"><div className="checkout-lines">{cartItems.map((item) => <article className="checkout-line" key={item.id}><Picture image={item.image} alt={item.name} /><div><b>{item.name}</b><small>{formatMoney(item.price)} cada una</small><div className="quantity-control"><button aria-label="Disminuir cantidad" onClick={() => changeCart(item.id, -1)}><Minus size={13} /></button><span>{item.quantity}</span><button aria-label="Aumentar cantidad" onClick={() => changeCart(item.id, 1)}><Plus size={13} /></button></div></div><strong>{formatMoney(item.price * item.quantity)}</strong></article>)}<button className="subtle-link" onClick={() => setCart({})}><Trash2 size={14} /> Vaciar carrito</button></div><div className="form-panel"><form onSubmit={confirmOrder}><label>Nombre completo<input name="name" required minLength="3" defaultValue={user?.name || ''} /></label><label>WhatsApp o correo<input name="contact" required defaultValue={user?.email || ''} /></label><label>Método de pago que prefieres conversar<select value={selectedPayment} onChange={(event) => setSelectedPayment(event.target.value)}><option>Mercado Pago (pendiente de integración)</option><option>PayPal (pendiente de integración)</option><option>Tarjeta mediante pasarela (pendiente)</option><option>Transferencia SPEI por acordar</option><option>Efectivo al recoger</option></select></label><div className="checkout-total"><span>Total de referencia</span><strong>{formatMoney(cartTotal)} MXN</strong></div><p className="secure-note"><ShieldCheck size={16} /> Este es un apartado provisional, no un pago. No ingreses datos bancarios.</p><button className="primary-button" type="submit">Apartar cuaderno <ArrowRight size={15} /></button></form></div></div> : pendingOrder ? <div className="success-panel"><span><Check size={24} /></span><h2>Apartado recibido</h2><p>Número {pendingOrder.id}. Total de referencia: {formatMoney(pendingOrder.total)}. No se realizó ningún cobro; el equipo se pondrá en contacto para confirmar disponibilidad.</p><button className="primary-button" onClick={() => navigate('pedidos')}>Ver mis apartados <ArrowRight size={15} /></button></div> : <EmptyState title="Tu carrito está vacío." copy="Explora las libretas artesanales para comenzar un apartado." action={() => navigate('cuadernos')} actionText="Ver libretas" />}</section>}

      {view === 'admin' && <section className="content-page admin-page">{!isAdmin ? <EmptyState title="Sección de administración." copy="Inicia sesión con una cuenta administradora del CBTis 122 para revisar publicaciones y solicitudes." action={() => { setAuthNotice('Inicia sesión con tu cuenta administradora.'); setModal('auth') }} actionText="Iniciar sesión" /> : <>
        {pageTitle('PANEL DEL COMITÉ', 'Administración', 'Publicaciones, solicitudes y donaciones de cuadernos recibidas.')}
        <div className="admin-metrics"><div><small>Publicaciones activas</small><strong>{posts.filter((post) => post.status === 'ok').length}</strong></div><div><small>Pendientes de revisión</small><strong>{posts.filter((post) => post.status === 'review').length}</strong></div><div><small>Solicitudes privadas</small><strong>{requests.length}</strong></div><div><small>Cuadernos donados</small><strong>{physicalDonations.reduce((sum, donation) => sum + donation.n, 0)}</strong></div></div>
        <AdminSection title="Publicaciones pendientes">{posts.filter((post) => post.status === 'review').map((post) => <article className="record-row" key={post.id}><img className="record-thumb" src={post.img} alt="" /><div><b>{post.n} · {post.t}</b><p>{post.by} · {post.c} · {post.why}</p><small>Pendiente de revisión</small></div><div className="record-actions"><button onClick={() => updatePost(post.id, 'ok')}>Aprobar</button><button className="danger-action" onClick={() => updatePost(post.id, 'rejected')}>Rechazar</button></div></article>)}{posts.every((post) => post.status !== 'review') && <p className="quiet-copy">No hay publicaciones pendientes.</p>}</AdminSection>
        <AdminSection title="Solicitudes privadas">{requests.map((request) => <article className="record-row" key={request.id}><div><b>{request.que}</b><p>{request.nom} · {request.em} · {request.via}</p><small>{formatDate(request.ts)}</small></div><button onClick={() => { setRequests((current) => current.map((item) => item.id === request.id ? { ...item, at: true } : item)); addNotice(request.em, 'El comité atendió tu solicitud.'); }}>{request.at ? 'Atendida' : 'Marcar atendida'}</button></article>)}{!requests.length && <p className="quiet-copy">No hay solicitudes privadas.</p>}</AdminSection>
        <AdminSection title="Donaciones físicas de cuadernos">{physicalDonations.map((donation) => <article className="record-row" key={donation.id}><div><b>{donation.n} cuaderno(s) · {donation.nom}</b><p>{donation.dir} · Tel. {donation.tel}</p><small>{formatDate(donation.ts)}</small></div><button onClick={() => updateDonation(donation.id, 'Recibida')}>{donation.est === 'Recibida' ? 'Recibida' : 'Marcar recibida'}</button></article>)}{!physicalDonations.length && <p className="quiet-copy">No hay donaciones físicas registradas.</p>}</AdminSection>
        <AdminSection title="Aportaciones económicas">{moneyDonations.map((donation) => <article className="record-row" key={donation.id}><div><b>{donation.name} · {donation.method}</b><p>{donation.email} · {donation.status}</p><small>{formatDate(donation.ts)}</small></div><strong>{formatMoney(donation.amount)}</strong></article>)}{!moneyDonations.length && <p className="quiet-copy">No hay aportaciones registradas.</p>}</AdminSection>
        </>}</section>}

      {view === 'legal' && <section className="content-page legal-page">{pageTitle('INFORMACIÓN DEL PROYECTO', policies[legalPage].title, 'Borrador para revisión por parte de la institución.')}{policies[legalPage].sections.map(([heading, copy]) => <article className="legal-section" key={heading}><h2>{heading}</h2><p>{copy}</p></article>)}<div className="secure-note"><ShieldCheck size={16} /> Hay información institucional pendiente de completar antes de publicar estas políticas.</div></section>}
    </main>

    <footer className="site-footer"><div className="footer-main"><div className="footer-about"><Link className="reto-brand" to="/"><span className="reto-logo"><Leaf size={21} /></span><span><b>EcoCambio</b><small>CBTis 122 · ODS 12</small></span></Link><p>Proyecto estudiantil para compartir materiales escolares y dar otra vida a los cuadernos usados.</p><small>Educación de calidad · Consumo responsable</small></div><div><h3>Explora</h3><a href="#catalogo">Catálogo escolar</a><a href="#publicar">Publicar artículo</a><a href="#cuadernos">Cuadernos con causa</a><Link to="/quienes-somos">Quiénes somos</Link></div><div><h3>Comunidad</h3><a href="#necesito">Lo necesito</a><a href="#dona-cuadernos">Donar cuadernos</a><a href="#donar">Donación económica</a><a href="#comentarios">Comentarios</a></div><div><h3>Información</h3><Link to="/terminos">Términos de uso</Link><Link to="/condiciones">Condiciones del servicio</Link><button onClick={() => showPolicy('privacy')}>Privacidad y datos</button><button onClick={() => showPolicy('platform')}>Uso de la plataforma</button><button onClick={() => showPolicy('purchases')}>Compras y pagos</button><button onClick={() => showPolicy('donations')}>Política de donaciones</button></div></div><div className="footer-bottom"><span>© {new Date().getFullYear()} EcoCambio · CBTis 122 · ODS 12</span><span>Proyecto de la comunidad escolar</span></div></footer>

    {modal === 'auth' && <Modal onClose={() => setModal('')}><div className="modal-top"><span className="modal-icon"><LockKeyhole size={20} /></span><button className="close-button" aria-label="Cerrar" onClick={() => setModal('')}><X size={19} /></button></div><span className="eyebrow">COMUNIDAD CBTis 122</span><h2 className="modal-title">{authMode === 'login' ? 'Qué bueno verte.' : 'Crea tu cuenta.'}</h2><p className="modal-copy">{authMode === 'login' ? 'Entra para publicar, comentar y participar.' : 'Una cuenta del plantel permite publicar y pedir artículos.'}</p><div className="auth-tabs"><button className={authMode === 'login' ? 'tab-active' : ''} onClick={() => { setAuthMode('login'); setAuthError('') }}>Iniciar sesión</button><button className={authMode === 'register' ? 'tab-active' : ''} onClick={() => { setAuthMode('register'); setAuthError('') }}>Crear cuenta</button></div><form className="auth-form" onSubmit={submitAuth}>{authMode === 'register' && <><div className="account-type-picker"><button type="button" className={registerAsPlantel ? 'type-selected' : ''} onClick={() => setRegisterAsPlantel(true)}>Soy del plantel</button><button type="button" className={!registerAsPlantel ? 'type-selected' : ''} onClick={() => setRegisterAsPlantel(false)}>Visitante</button></div><label>Nombre completo<input name="name" autoComplete="name" required /></label>{registerAsPlantel && <label>Número de control<input name="studentNumber" inputMode="numeric" minLength="8" maxLength="14" required /></label>}</>}<label>Correo electrónico<input name="email" type="email" autoComplete="email" required /></label><label>Contraseña<input name="password" type="password" autoComplete={authMode === 'login' ? 'current-password' : 'new-password'} minLength="6" required /></label>{authError && <p className="form-error" role="alert">{authError}</p>}{authNotice && <p className="auth-notice">{authNotice}</p>}<button className="primary-button" type="submit">{authMode === 'login' ? 'Entrar' : 'Crear mi cuenta'} <ArrowRight size={15} /></button><p className="quiet-copy">La cuenta de esta demostración se guarda solo en este navegador.</p></form></Modal>}

    {modal === 'physical' && <Modal onClose={() => setModal('')}><div className="modal-top"><span className="modal-icon"><Heart size={20} /></span><button className="close-button" aria-label="Cerrar" onClick={() => setModal('')}><X size={19} /></button></div>{physicalComplete ? <div className="success-panel modal-success"><span><Check size={24} /></span><span className="eyebrow">REGISTRO LOCAL</span><h2>Gracias por querer compartir.</h2><p>La información quedó guardada solo en este navegador. Todavía no se envía al comité ni permite coordinar la recepción en línea.</p><button className="primary-button" onClick={() => setModal('')}>Cerrar <Check size={15} /></button></div> : <><span className="eyebrow">DONACIÓN FÍSICA · NO ES UNA VENTA</span><h2 className="modal-title">Dona tus cuadernos.</h2><p className="modal-copy">Cada cuaderno con hojas útiles puede convertirse en una libreta artesanal. Este formulario es una demostración local hasta conectar el servicio de recepción.</p><form className="auth-form" onSubmit={savePhysicalDonation}><label>Nombre completo<input name="fullName" autoComplete="name" required minLength="3" /></label><label>Dirección<input name="address" autoComplete="street-address" required minLength="5" /></label><label>Número de teléfono<input name="phone" type="tel" inputMode="tel" autoComplete="tel" pattern="[0-9()+ -]{10,18}" required title="Escribe un teléfono válido" /></label><label>Cantidad de cuadernos<input name="quantity" type="number" min="1" step="1" required /></label><div className="modal-actions"><button type="button" className="secondary-button" onClick={() => setModal('')}>Cancelar</button><button className="primary-button" type="submit">Confirmar donación <ArrowRight size={15} /></button></div></form></>}</Modal>}

    {modal === 'cart' && <>
      <button className="drawer-scrim" aria-label="Cerrar carrito" onClick={() => setModal('')} />
      <aside className="cart-drawer" aria-label="Carrito de libretas">
        <div className="drawer-heading">
          <div><span className="eyebrow">CUADERNOS CON CAUSA</span><h2>Tu carrito <small>{cartCount} productos</small></h2></div>
          <button className="close-button" aria-label="Cerrar carrito" onClick={() => setModal('')}><X size={19} /></button>
        </div>
        <div className="drawer-products">
          {cartItems.length ? cartItems.map((item) => (
            <article className="drawer-product" key={item.id}>
              <Picture image={item.image} alt={item.name} />
              <div><b>{item.name}</b><small>{formatMoney(item.price)} c/u</small>
                <div className="quantity-control">
                  <button aria-label={`Quitar una unidad de ${item.name}`} onClick={() => changeCart(item.id, -1)}><Minus size={13} /></button>
                  <span>{item.quantity}</span>
                  <button aria-label={`Agregar una unidad de ${item.name}`} disabled={item.quantity >= item.stock} onClick={() => changeCart(item.id, 1)}><Plus size={13} /></button>
                </div>
              </div>
              <div className="drawer-product-price"><b>{formatMoney(item.price * item.quantity)}</b>
                <button aria-label={`Eliminar ${item.name}`} onClick={() => setCart((current) => { const next = { ...current }; delete next[item.id]; return next })}><Trash2 size={15} /></button>
              </div>
            </article>
          )) : <EmptyState title="Tu carrito está vacío." copy="Agrega una libreta artesanal para comenzar." action={() => { setModal(''); navigate('cuadernos') }} actionText="Ver libretas" />}
        </div>
        {cartItems.length > 0 && <div className="drawer-bottom">
          <div><span>Subtotal</span><b>{formatMoney(cartTotal)}</b></div>
          <div><span>Total a pagar</span><b>{formatMoney(cartTotal)} MXN</b></div>
          <p>No se realizará ningún cobro en este sitio.</p>
          <button className="primary-button" onClick={() => { setModal(''); setPendingOrder(null); navigate('pedido') }}>Continuar al pedido <ArrowRight size={15} /></button>
          <button className="clear-cart" onClick={() => setCart({})}>Vaciar carrito</button>
        </div>}
      </aside>
    </>}

    {modal === 'notices' && <Modal onClose={() => setModal('')}><div className="modal-top"><span className="modal-icon"><MessageCircle size={20} /></span><button className="close-button" onClick={() => setModal('')} aria-label="Cerrar"><X size={19} /></button></div><h2 className="modal-title">Avisos</h2>{notices.filter((notice) => notice.to === user?.email || (isAdmin && notice.to === 'admin')).map((notice, index) => <article className="notice-row" key={`${notice.ts}-${index}`}><p>{notice.message}</p><small>{formatDate(notice.ts)}</small></article>)}</Modal>}
    {modal === 'legal' && <Modal onClose={() => setModal('')} wide><div className="modal-top"><span className="modal-icon"><ShieldCheck size={20} /></span><button className="close-button" onClick={() => setModal('')} aria-label="Cerrar"><X size={19} /></button></div><h2 className="modal-title">{policies[legalPage].title}</h2>{policies[legalPage].sections.map(([heading, copy]) => <article className="legal-modal-section" key={heading}><h3>{heading}</h3><p>{copy}</p></article>)}</Modal>}
    {toast && <div className="toast-message" role="status"><Check size={16} />{toast}</div>}
  </div>
}

function EmptyState({ title, copy = '', action, actionText = '' }) {
  return <div className="empty-state"><span><Leaf size={20} /></span><h2>{title}</h2>{copy && <p>{copy}</p>}{action && <button className="subtle-link" onClick={action}>{actionText} <ArrowRight size={14} /></button>}</div>
}

function AdminSection({ title, children }) {
  return <section className="admin-section"><div className="section-heading-row"><h2>{title}</h2></div>{children}</section>
}

function Modal({ onClose, children, wide = false }) {
  return <div className="modal-backdrop" onMouseDown={(event) => event.target === event.currentTarget && onClose()}><section className={`modal-window ${wide ? 'modal-wide' : ''}`} role="dialog" aria-modal="true">{children}</section></div>
}

export default App