import { Link } from 'react-router'
import PageLayout from './PageLayout.jsx'

export default function Terminos() {
  return (
    <PageLayout>
      <header className="page-heading">
        <span className="eyebrow">INFORMACIÓN DEL PROYECTO</span>
        <h1>Términos de uso</h1>
        <p>Resumen para la actividad académica. La institución debe revisar y completar este texto antes de publicar una versión oficial.</p>
      </header>
      <article className="legal-section"><h2>Uso de EcoCambio</h2><p>EcoCambio es un proyecto escolar del CBTis 122 para facilitar el intercambio y la donación de artículos útiles, y dar visibilidad a las libretas elaboradas con cuadernos recuperados. Las publicaciones deben respetar las reglas de convivencia del plantel.</p></article>
      <article className="legal-section"><h2>Participación y entregas</h2><p>La participación en el catálogo escolar está destinada a integrantes de la comunidad del CBTis 122. Las entregas se coordinan entre las personas participantes y se propone la biblioteca del plantel como punto de encuentro, sujeto a confirmación de sus horarios y autorización.</p></article>
      <article className="legal-section"><h2>Versión de demostración</h2><p>Esta versión almacena información en el navegador y no sincroniza publicaciones entre dispositivos. Los pedidos de libretas y las aportaciones son registros provisionales; no se procesan cobros ni se confirma disponibilidad.</p></article>
      <Link className="subtle-link route-page-action" to="/">← Volver al inicio</Link>
    </PageLayout>
  )
}