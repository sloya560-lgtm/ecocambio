import { useEffect } from 'react'
import { Leaf } from 'lucide-react'
import { Link, useLocation } from 'react-router'

export default function PageLayout({ children }) {
  const { pathname } = useLocation()

  useEffect(() => {
    const titles = {
      '/login': 'Iniciar sesión',
      '/quienes-somos': 'Quiénes somos',
      '/terminos': 'Términos de uso',
      '/condiciones': 'Condiciones del servicio',
      '/dashboard': 'Dashboard',
    }
    document.title = `${titles[pathname] || 'Página no encontrada'} · EcoCambio · CBTis 122`
  }, [pathname])

  return (
    <div className="reto-app">
      <div className="top-ribbon"><Leaf size={13} /> Una comunidad que da otra vuelta a las cosas</div>
      <header className="apple-header page-shell-header">
        <Link className="reto-brand" to="/" aria-label="EcoCambio, inicio">
          <span className="reto-logo"><Leaf size={21} /></span>
          <span><b>EcoCambio</b><small>CBTis 122 · ODS 12</small></span>
        </Link>
        <nav className="page-route-nav" aria-label="Navegación de páginas">
          <Link to="/">Inicio</Link>
          <Link to="/quienes-somos">Quiénes somos</Link>
          <Link to="/terminos">Términos</Link>
          <Link to="/condiciones">Condiciones</Link>
        </nav>
      </header>
      <main className="main-content">
        <section className="content-page route-page">{children}</section>
      </main>
      <footer className="site-footer">
        <div className="footer-bottom"><span>EcoCambio · CBTis 122 · ODS 12</span><Link to="/">Volver al inicio</Link></div>
      </footer>
    </div>
  )
}