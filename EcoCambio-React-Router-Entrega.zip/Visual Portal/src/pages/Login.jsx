import { ArrowRight, LockKeyhole } from 'lucide-react'
import { Link, useNavigate } from 'react-router'
import PageLayout from './PageLayout.jsx'

export default function Login() {
  const navigate = useNavigate()

  function handleSubmit(event) {
    event.preventDefault()
    navigate('/dashboard')
  }

  return (
    <PageLayout>
      <div className="route-form-wrap">
        <header className="page-heading">
          <span className="eyebrow">COMUNIDAD CBTis 122</span>
          <h1>Iniciar sesión</h1>
          <p>Entra al espacio de EcoCambio para continuar.</p>
        </header>
        <form className="form-panel auth-form" onSubmit={handleSubmit}>
          <label>Correo electrónico<input name="email" type="email" autoComplete="email" /></label>
          <label>Contraseña<input name="password" type="password" autoComplete="current-password" /></label>
          <button className="primary-button" type="submit"><LockKeyhole size={16} /> Entrar al Dashboard <ArrowRight size={16} /></button>
          <p className="quiet-copy">Esta pantalla es una demostración académica; no valida cuentas ni contraseñas.</p>
        </form>
        <Link className="subtle-link route-back-link" to="/">← Volver al inicio</Link>
      </div>
    </PageLayout>
  )
}