import { Link } from 'react-router'
import PageLayout from './PageLayout.jsx'

export default function Condiciones() {
  return (
    <PageLayout>
      <header className="page-heading">
        <span className="eyebrow">CONDICIONES DEL SERVICIO</span>
        <h1>Condiciones de participación</h1>
        <p>Estas condiciones describen el funcionamiento actual de la demostración EcoCambio.</p>
      </header>
      <article className="legal-section"><h2>Publicaciones y artículos</h2><p>Los artículos ofrecidos deben ser escolares o de uso personal y describirse con honestidad. Las publicaciones pueden quedar pendientes de revisión por el equipo del proyecto.</p></article>
      <article className="legal-section"><h2>Donaciones y solicitudes</h2><p>Registrar una donación o solicitud en esta versión no coordina por sí solo una entrega. El comité debe confirmar la recepción de materiales y acordar directamente cualquier seguimiento.</p></article>
      <article className="legal-section"><h2>Pedidos y pagos</h2><p>Los pedidos de libretas son apartados provisionales. No hay pasarela de pago conectada y no se deben ingresar datos bancarios en el sitio.</p></article>
      <article className="legal-section"><h2>Datos personales</h2><p>Los datos de demostración se guardan localmente en el navegador. No ingreses información sensible. Antes de operar públicamente, el plantel debe publicar su aviso de privacidad y los medios oficiales de contacto.</p></article>
      <Link className="subtle-link route-page-action" to="/">← Volver al inicio</Link>
    </PageLayout>
  )
}