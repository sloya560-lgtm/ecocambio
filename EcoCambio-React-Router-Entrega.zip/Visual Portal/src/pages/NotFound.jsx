import { ArrowLeft, Search } from 'lucide-react'
import { Link } from 'react-router'
import PageLayout from './PageLayout.jsx'

export default function NotFound() {
  return (
    <PageLayout>
      <div className="empty-state route-not-found">
        <span><Search size={20} /></span>
        <span className="eyebrow">ERROR 404</span>
        <h1>No encontramos esa página.</h1>
        <p>Puede que la dirección haya cambiado o que no exista.</p>
        <Link className="primary-button" to="/"><ArrowLeft size={16} /> Volver al inicio</Link>
      </div>
    </PageLayout>
  )
}