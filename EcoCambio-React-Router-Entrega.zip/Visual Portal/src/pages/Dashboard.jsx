import { ArrowRight, BookOpen, Heart, Leaf, LockKeyhole } from 'lucide-react'
import { Link } from 'react-router'
import PageLayout from './PageLayout.jsx'

export default function Dashboard() {
  return (
    <PageLayout>
      <header className="page-heading">
        <span className="eyebrow"><Leaf size={14} /> PANEL DE ECOCAMBIO</span>
        <h1>Tu espacio para compartir.</h1>
        <p>Desde aquí puedes volver a conocer la iniciativa, revisar las libretas con causa o entrar al sitio completo de EcoCambio.</p>
      </header>
      <div className="dashboard-route-grid">
        <Link to="/#publico"><Heart size={20} /><span><b>Espacio público</b><small>Conoce cómo ayudar y donar materiales.</small></span><ArrowRight size={16} /></Link>
        <Link to="/#cuadernos"><BookOpen size={20} /><span><b>Cuadernos con causa</b><small>Descubre el proyecto de libretas artesanales.</small></span><ArrowRight size={16} /></Link>
        <Link to="/#catalogo"><LockKeyhole size={20} /><span><b>Comunidad escolar</b><small>Visita el catálogo e inicia sesión para participar.</small></span><ArrowRight size={16} /></Link>
      </div>
      <div className="hero-buttons route-dashboard-actions">
        <Link className="primary-button" to="/">Cerrar sesión <ArrowRight size={16} /></Link>
        <Link className="plain-button" to="/">Volver al inicio</Link>
      </div>
    </PageLayout>
  )
}