import { ArrowRight, Link as LinkIcon } from 'lucide-react'
import { Link } from 'react-router'
import PageLayout from './PageLayout.jsx'

export default function QuienesSomos() {
  return (
    <PageLayout>
      <header className="page-heading">
        <span className="eyebrow">NUESTRA HISTORIA</span>
        <h1>¿Qué es EcoCambio?</h1>
        <p>Una iniciativa estudiantil del CBTis 122 para compartir recursos escolares, reutilizar materiales y acompañar a la comunidad.</p>
      </header>
      <div className="about-feature route-about-feature">
        <div className="route-about-mark"><LinkIcon size={34} /></div>
        <div><span className="eyebrow">UN PROYECTO DE LA COMUNIDAD</span><h2>Lo útil puede encontrar una nueva historia.</h2><p>EcoCambio conecta artículos escolares que todavía sirven con estudiantes que pueden aprovecharlos. También recupera cuadernos para transformarlos en libretas artesanales y apoyar una meta educativa.</p></div>
      </div>
      <div className="mission-columns">
        <article><span>01</span><h3>Compartir</h3><p>Facilitar la donación y el intercambio de materiales escolares.</p></article>
        <article><span>02</span><h3>Reutilizar</h3><p>Dar otra vida a los cuadernos y reducir el desperdicio de papel.</p></article>
        <article><span>03</span><h3>Acompañar</h3><p>Fortalecer una comunidad escolar donde pedir y ofrecer ayuda sea sencillo.</p></article>
      </div>
      <Link className="primary-button route-page-action" to="/">Volver al inicio <ArrowRight size={16} /></Link>
    </PageLayout>
  )
}