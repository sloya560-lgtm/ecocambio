export const MarcoRunico = ({ titulo, children }) => {
  return (
    <div className="marco-runico-border">
      <header>
        <span>💎</span>
        <h2>{titulo}</h2>
      </header>

      <section className="tarjeta-nodo">
        {children}
      </section>
    </div>
  );
};