export const PanelReglas = () => (
  <ul className="lista-iniciados">
    <li>1. Mantener las funciones puras sin efectos secundarios.</li>
    <li>2. Usar className y camelCase en todos los atributos.</li>
    <li>3. Cerrar siempre las etiquetas autocontenidas.</li>
  </ul>
);