export default function TarjetaMision({ titulo, recompensa, dificultad, completada = false }) {
  return (
    <article className="tarjeta-mision">
      <header className="cabecera-mision">
        <h3>{titulo}</h3>
        <span className={`badge ${dificultad.toLowerCase()}`}>{dificultad}</span>
      </header>
      <div className="cuerpo-mision">
        <p>
          Recompensa: <strong>{recompensa} monedas de oro</strong>
        </p>
        <p>Estado: {completada ? "✅ Cumplida" : "⏳ En progreso"}</p>
      </div>
    </article>
  );
}
