import { ArrowDownRight, ArrowUpRight } from "lucide-react";

export default function KpiCard({ label, valor, prefijo, sufijo, cambio, esPositivo }) {
  return (
    <article className="flex min-h-[170px] flex-col justify-between rounded-xl border border-neutral-300 bg-white p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <span className="text-[10px] font-semibold uppercase tracking-[0.18em] text-neutral-500">
          {label}
        </span>
        <div className="flex h-6 w-6 items-center justify-center rounded border border-neutral-300 text-[10px] text-neutral-400">
          ✕
        </div>
      </div>

      <div className="my-2">
        <span className="text-3xl font-extrabold tracking-tight text-neutral-900">
          {prefijo}
          {valor}
          {sufijo}
        </span>
      </div>

      <div className="flex items-center justify-between pt-1">
        <div
          className={`flex items-center gap-1 text-xs font-semibold ${
            esPositivo ? "text-emerald-600" : "text-rose-600"
          }`}
        >
          {esPositivo ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
          <span>{cambio}</span>
        </div>
        <div className="flex h-5 w-5 items-center justify-center rounded border border-neutral-200 text-[10px] text-neutral-400">
          ✕
        </div>
      </div>
    </article>
  );
}
