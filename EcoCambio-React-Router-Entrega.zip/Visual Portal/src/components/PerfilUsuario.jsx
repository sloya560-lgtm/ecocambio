export const PerfilUsuario = ({ usuario }) => (
  <div className="card-iniciado">
    <h3>Avatar: {usuario.nombre}</h3>
    <p>Rol: {usuario.rol}</p>
    <small>Último acceso: {usuario.ultimoAcceso}</small>
  </div>
);