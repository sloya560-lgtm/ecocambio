export default function ContenedorArcano({ tituloSeccion, children }) {
  return (
    <section className="borde-runico">
      <h2 className="cabecera-dorada">{tituloSeccion}</h2>
      <div className="contenido-ranura">{children}</div>
    </section>
  );
}
