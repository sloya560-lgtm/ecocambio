import React from 'react';
import './LoginModerno.css';

const LoginModerno = ({ title, btnText }) => {
    return (
        <div className="login-container">

            <h1>{title}</h1>

            <div className="recover">
                <a href="/recuperar">¿Olvidaste tu contraseña?</a>
            </div>

            <form>

                {/* Campo de Correo Electrónico */}
                <div className="field">
                    <label htmlFor="email">
                        <span className="field-label">
                            Correo electrónico
                        </span>
                    </label>

                    <input
                        type="email"
                        id="email"
                        name="email"
                        autoCapitalize="none"
                        autoCorrect="off"
                        spellCheck={false}
                    />
                </div>

                {/* Campo de Contraseña */}
                <div className="field">
                    <label htmlFor="password">
                        <span className="field-label">
                            Contraseña
                        </span>
                    </label>

                    <div className="password-wrapper">
                        <input
                            type="password"
                            id="password"
                            name="password"
                        />

                        <button
                            type="button"
                            aria-pressed="false"
                        >
                            Mostrar
                        </button>
                    </div>
                </div>

                {/* Botón de inicio de sesión */}
                <div className="submit-wrapper">
                    <button type="submit">
                        {btnText}
                    </button>
                </div>

            </form>

            <div className="registro-link">
                <p>
                    ¿Aún no tienes cuenta?
                    <a href="/registro"> Regístrate aquí</a>
                </p>
            </div>

        </div>
    );
};

export default LoginModerno;